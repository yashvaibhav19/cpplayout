#include <iostream>

int main()
{
	std::cout << "Good luck using this layout\n";
	return 0;
}
